package com.example.Exam.exception;

public class PerformerExistsException extends RuntimeException{
}
