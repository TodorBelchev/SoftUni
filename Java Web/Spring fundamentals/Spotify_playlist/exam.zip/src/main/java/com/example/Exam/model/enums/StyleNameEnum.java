package com.example.Exam.model.enums;

public enum StyleNameEnum {
    POP, ROCK, JAZZ
}
