package com.example.Exam.exception;

public class UsernameExistsException extends RuntimeException{
}
